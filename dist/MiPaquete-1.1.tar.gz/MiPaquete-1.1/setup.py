from setuptools import setup

setup(
    name='MiPaquete',
    version='1.1',
    author='Mateo Quartin',
    description='pre entrega 2',
    author_email='mateoquartin@gmail.com',
    packages=['pakete1'],
)